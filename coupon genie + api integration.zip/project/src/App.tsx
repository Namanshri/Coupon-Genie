import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { Gift } from 'lucide-react';
import Features from './components/Features';
import Predict from './components/Predict';
import About from './components/About';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <nav className="bg-white shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-16">
              <div className="flex items-center">
                <Link to="/" className="flex items-center">
                  <Gift className="h-8 w-8 text-purple-600" />
                  <span className="ml-2 text-xl font-bold text-gray-900">Coupon Genie</span>
                </Link>
              </div>
              <div className="flex items-center space-x-8">
                <Link to="/" className="text-gray-600 hover:text-purple-600">Features</Link>
                <Link to="/predict" className="text-gray-600 hover:text-purple-600">Predict</Link>
                <Link to="/about" className="text-gray-600 hover:text-purple-600">About</Link>
              </div>
            </div>
          </div>
        </nav>

        <Routes>
          <Route path="/" element={<Features />} />
          <Route path="/predict" element={<Predict />} />
          <Route path="/about" element={<About />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;