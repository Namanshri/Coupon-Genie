interface CouponPrediction {
  probability: number;
  recommendedCoupons: {
    category: string;
    brand: string;
    discount: number;
    description: string;
  }[];
}

interface MockData {
  [key: string]: {
    [key: string]: {
      [key: string]: {
        [key: string]: {
          [key: string]: CouponPrediction;
        };
      };
    };
  };
}

const generateCoupons = (category: string, season: string) => {
  const coupons = {
    Food: {
      brands: ['Swiggy', 'Zomato', 'Dominos', 'KFC', 'ZeptoCafe'],
      seasonal: {
        Summer: ['summer special', 'refreshing beverages', 'ice cream fest'],
        Winter: ['hot & spicy', 'winter special', 'hot beverages'],
        Monsoon: ['monsoon special', 'hot soups', 'chai time'],
        Wedding: ['party packages', 'catering special', 'group orders']
      }
    },
    Travel: {
      brands: ['MakeMyTrip', 'Goibibo', 'Ixigo', 'EaseMyTrip', 'Agoda'],
      seasonal: {
        Summer: ['summer gateway', 'beach vacation', 'hill station'],
        Winter: ['winter retreat', 'ski destinations', 'new year special'],
        Monsoon: ['monsoon deals', 'weekend gateway', 'staycation'],
        Wedding: ['honeymoon package', 'destination wedding', 'group booking']
      }
    },
    Electronics: {
      brands: ['Amazon', 'Flipkart', 'Samsung', 'Philips', 'LG'],
      seasonal: {
        Summer: ['summer appliances', 'AC offers', 'cooling solutions'],
        Winter: ['winter appliances', 'heating solutions', 'smart devices'],
        Monsoon: ['monsoon protection', 'waterproof gadgets', 'indoor entertainment'],
        Wedding: ['wedding gifts', 'home appliances', 'smart home bundle']
      }
    },
    Fashion: {
      brands: ['Myntra', 'Ajio', 'Nykaa', 'Savana', 'Urbanic'],
      seasonal: {
        Summer: ['summer collection', 'cotton wear', 'beachwear'],
        Winter: ['winter wear', 'woolen collection', 'layered fashion'],
        Monsoon: ['rain wear', 'waterproof collection', 'monsoon fashion'],
        Wedding: ['wedding collection', 'festive wear', 'traditional wear']
      }
    }
  };

  const categoryData = coupons[category as keyof typeof coupons];
  const brands = categoryData.brands;
  const seasonalThemes = categoryData.seasonal[season as keyof typeof categoryData.seasonal];
  
  return brands.map((brand, index) => ({
    category,
    brand,
    discount: Math.floor(Math.random() * 20) + 20, // Random discount between 20-40%
    description: `${brand}: ${seasonalThemes[index % seasonalThemes.length]} - Special Offer!`
  }));
};

const generatePredictionData = () => {
  const ageGroups = ['18-25', '26-35', '36-45', '46+'];
  const genders = ['Male', 'Female', 'Other'];
  const incomes = ['Below 3 LPA', '3-6 LPA', '6-10 LPA', 'Above 10 LPA'];
  const categories = ['Food', 'Travel', 'Electronics', 'Fashion'];
  const seasons = ['Summer', 'Winter', 'Monsoon', 'Wedding'];

  const data: MockData = {};

  ageGroups.forEach(age => {
    data[age] = {};
    genders.forEach(gender => {
      data[age][gender] = {};
      incomes.forEach(income => {
        data[age][gender][income] = {};
        categories.forEach(category => {
          data[age][gender][income][category] = {};
          seasons.forEach(season => {
            data[age][gender][income][category][season] = {
              probability: 0.5 + Math.random() * 0.5, // Random probability between 0.5-1
              recommendedCoupons: generateCoupons(category, season)
            };
          });
        });
      });
    });
  });

  return data;
};

export const mockData: MockData = generatePredictionData();