import React from 'react';
import { TrendingUp, Users, DollarSign, BarChart3, Brain, Target } from 'lucide-react';

function Features() {
  const features = [
    {
      icon: <TrendingUp className="h-8 w-8 text-purple-600" />,
      title: "Accurate Predictions",
      description: "Our advanced ML algorithms analyze customer behavior patterns to predict purchase probability with up to 95% accuracy. Make data-driven decisions with confidence."
    },
    {
      icon: <Users className="h-8 w-8 text-purple-600" />,
      title: "Customer Insights",
      description: "Gain deep understanding of customer preferences across demographics, seasons, and categories. Identify trends before they emerge."
    },
    {
      icon: <DollarSign className="h-8 w-8 text-purple-600" />,
      title: "ROI Optimization",
      description: "Maximize returns by targeting the right customers with the right offers. Reduce marketing waste and increase conversion rates."
    },
    {
      icon: <BarChart3 className="h-8 w-8 text-purple-600" />,
      title: "Real-time Analytics",
      description: "Monitor campaign performance in real-time. Get instant insights into customer responses and adjust strategies on the fly."
    },
    {
      icon: <Brain className="h-8 w-8 text-purple-600" />,
      title: "Smart Segmentation",
      description: "Automatically segment customers based on behavior patterns. Create targeted campaigns for different customer groups."
    },
    {
      icon: <Target className="h-8 w-8 text-purple-600" />,
      title: "Personalized Recommendations",
      description: "Deliver tailored coupon suggestions based on individual shopping patterns and preferences. Increase engagement and loyalty."
    }
  ];

  return (
    <div className="py-12 bg-gradient-to-b from-purple-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Getting Insights into your Customer's Shopping Habits
          </h1>
          <p className="text-xl text-gray-600">
            Leverage machine learning to understand customer purchase patterns and optimize your coupon strategy.
          </p>
        </div>

        <div className="mt-16">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Key Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <div className="bg-purple-50 rounded-full w-16 h-16 flex items-center justify-center mb-4">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Features;