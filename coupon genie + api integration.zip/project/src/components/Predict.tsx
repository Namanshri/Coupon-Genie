import React, { useState } from 'react';
import { Brain } from 'lucide-react';
import { mockData } from '../mockData';

interface FormData {
  ageGroup: string;
  gender: string;
  annualIncome: string;
  couponCategory: string;
  season: string;
}

interface PredictionResult {
  probability: number;
  recommendedCoupons: {
    category: string;
    brand: string;
    discount: number;
    description: string;
  }[];
}

function Predict() {
  const [formData, setFormData] = useState<FormData>({
    ageGroup: '18-25',
    gender: 'Male',
    annualIncome: 'Below 3 LPA',
    couponCategory: 'Food',
    season: 'Summer'
  });
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    try {
      const result = mockData[formData.ageGroup]?.[formData.gender]?.[formData.annualIncome]?.[formData.couponCategory]?.[formData.season];
      
      if (!result) {
        throw new Error('No prediction available for the selected combination');
      }

      setPrediction(result);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'An error occurred while fetching prediction');
      setPrediction(null);
    }
  };

  return (
    <div className="py-12 bg-gradient-to-b from-purple-50 to-white min-h-screen">
      <div className="max-w-md mx-auto px-4">
        <div className="bg-white p-8 rounded-lg shadow-md">
          <div className="flex items-center justify-center mb-6">
            <div className="bg-purple-100 rounded-full p-3">
              <Brain className="h-8 w-8 text-purple-600" />
            </div>
          </div>
          <h2 className="text-2xl font-bold text-center text-gray-900 mb-8">
            Predict Purchase Probability
          </h2>
          
          <form onSubmit={handleSubmit}>
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Age Group
                </label>
                <select
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-purple-500 focus:border-purple-500"
                  value={formData.ageGroup}
                  onChange={(e) => setFormData({...formData, ageGroup: e.target.value})}
                >
                  <option>18-25</option>
                  <option>26-35</option>
                  <option>36-45</option>
                  <option>46+</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Gender
                </label>
                <select
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-purple-500 focus:border-purple-500"
                  value={formData.gender}
                  onChange={(e) => setFormData({...formData, gender: e.target.value})}
                >
                  <option>Male</option>
                  <option>Female</option>
                  <option>Other</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Annual Income
                </label>
                <select
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-purple-500 focus:border-purple-500"
                  value={formData.annualIncome}
                  onChange={(e) => setFormData({...formData, annualIncome: e.target.value})}
                >
                  <option>Below 3 LPA</option>
                  <option>3-6 LPA</option>
                  <option>6-10 LPA</option>
                  <option>Above 10 LPA</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Season
                </label>
                <select
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-purple-500 focus:border-purple-500"
                  value={formData.season}
                  onChange={(e) => setFormData({...formData, season: e.target.value})}
                >
                  <option>Summer</option>
                  <option>Monsoon</option>
                  <option>Winter</option>
                  <option>Wedding</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Coupon Category
                </label>
                <select
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-purple-500 focus:border-purple-500"
                  value={formData.couponCategory}
                  onChange={(e) => setFormData({...formData, couponCategory: e.target.value})}
                >
                  <option>Food</option>
                  <option>Electronics</option>
                  <option>Fashion</option>
                  <option>Travel</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full bg-purple-600 text-white py-2 px-4 rounded-md hover:bg-purple-700 transition-colors"
              >
                Predict
              </button>
            </div>
          </form>

          {error && (
            <div className="mt-6 p-4 bg-red-50 rounded-md">
              <p className="text-sm text-red-600">{error}</p>
            </div>
          )}

          {prediction && (
            <div className="mt-6 p-4 bg-purple-50 rounded-md">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Prediction Result</h3>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-gray-600">Purchase Probability:</p>
                  <p className="text-lg font-semibold text-purple-600">
                    {(prediction.probability * 100).toFixed(1)}%
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-2">Recommended Coupons:</p>
                  <div className="space-y-2">
                    {prediction.recommendedCoupons.map((coupon, index) => (
                      <div key={index} className="bg-white p-3 rounded-md shadow-sm">
                        <p className="font-medium text-gray-900">{coupon.description}</p>
                        <p className="text-sm text-gray-600">
                          Brand: {coupon.brand} | Discount: {coupon.discount}%
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default Predict;