import { TrendingUp, Users, DollarSign, BarChart3, Brain, Gift } from 'lucide-react';

function FeatureCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <div className="flex justify-center mb-4">{icon}</div>
      <h3 className="text-xl font-semibold text-gray-900 text-center mb-4">{title}</h3>
      <p className="text-gray-600 text-center">{description}</p>
    </div>
  );
}

export default function Features() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-white py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-16">Key Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <FeatureCard
            icon={<TrendingUp className="h-8 w-8 text-purple-600" />}
            title="Accurate Predictions"
            description="Our advanced ML algorithms analyze customer behavior patterns to predict purchase probability with up to 95% accuracy. Make data-driven decisions with confidence."
          />
          <FeatureCard
            icon={<Users className="h-8 w-8 text-purple-600" />}
            title="Customer Insights"
            description="Gain deep understanding of customer preferences across demographics, seasons, and categories. Identify trends before they emerge."
          />
          <FeatureCard
            icon={<DollarSign className="h-8 w-8 text-purple-600" />}
            title="ROI Optimization"
            description="Maximize returns by targeting the right customers with the right offers. Reduce marketing waste and increase conversion rates."
          />
          <FeatureCard
            icon={<BarChart3 className="h-8 w-8 text-purple-600" />}
            title="Real-time Analytics"
            description="Monitor campaign performance in real-time. Get instant insights into customer responses and adjust strategies on the fly."
          />
          <FeatureCard
            icon={<Brain className="h-8 w-8 text-purple-600" />}
            title="Smart Segmentation"
            description="Automatically segment customers based on behavior patterns. Create targeted campaigns for different customer groups."
          />
          <FeatureCard
            icon={<Gift className="h-8 w-8 text-purple-600" />}
            title="Seasonal Optimization"
            description="Optimize coupon strategies for different seasons and occasions. From festivals to seasonal sales, maximize impact with timely offers."
          />
        </div>
      </div>
    </div>
  );
}