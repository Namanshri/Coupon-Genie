import { Brain } from 'lucide-react';
import { useState } from 'react';

export default function Predict() {
  const [predictData, setPredictData] = useState({
    ageGroup: '18-25',
    gender: 'Male',
    income: 'Below 3 LPA',
    category: 'Food'
  });

  const handlePredict = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle prediction
    console.log('Prediction requested:', predictData);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-white py-20">
      <div className="max-w-md mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <div className="flex justify-center mb-6">
            <Brain className="h-12 w-12 text-purple-600" />
          </div>
          <h2 className="text-2xl font-bold text-center text-gray-900 mb-8">
            Predict Purchase Probability
          </h2>
          <form onSubmit={handlePredict}>
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700">Age Group</label>
                <select
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                  value={predictData.ageGroup}
                  onChange={(e) => setPredictData({...predictData, ageGroup: e.target.value})}
                >
                  <option>18-25</option>
                  <option>26-35</option>
                  <option>36-45</option>
                  <option>46-55</option>
                  <option>56+</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Gender</label>
                <select
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                  value={predictData.gender}
                  onChange={(e) => setPredictData({...predictData, gender: e.target.value})}
                >
                  <option>Male</option>
                  <option>Female</option>
                  <option>Other</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Annual Income</label>
                <select
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                  value={predictData.income}
                  onChange={(e) => setPredictData({...predictData, income: e.target.value})}
                >
                  <option>Below 3 LPA</option>
                  <option>3-6 LPA</option>
                  <option>6-10 LPA</option>
                  <option>Above 10 LPA</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Coupon Category</label>
                <select
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                  value={predictData.category}
                  onChange={(e) => setPredictData({...predictData, category: e.target.value})}
                >
                  <option>Food</option>
                  <option>Travel</option>
                  <option>Retail</option>
                  <option>Entertainment</option>
                  <option>Clothing</option>
                  <option>Wedding Season</option>
                  <option>Summers</option>
                  <option>Winters</option>
                  <option>Monsoon</option>
                  <option>Vacations</option>
                  <option>Christmas</option>
                  <option>Diwali</option>
                </select>
              </div>
              <button
                type="submit"
                className="w-full bg-purple-600 text-white py-2 px-4 rounded-md hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2"
              >
                Predict
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}