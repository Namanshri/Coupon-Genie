import { Mail, Phone, Building2 } from 'lucide-react';
import { useState } from 'react';

function TeamMember({ name, role }: { name: string, role: string }) {
  return (
    <div className="text-center bg-white p-6 rounded-lg shadow-lg">
      <h3 className="text-lg font-semibold text-gray-900">{name}</h3>
      <p className="text-gray-600">{role}</p>
    </div>
  );
}

function ContactCard({ icon, title, content }: { icon: React.ReactNode, title: string, content: string }) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-lg text-center">
      <div className="flex justify-center mb-4">{icon}</div>
      <h3 className="text-lg font-semibold text-gray-900 mb-2">{title}</h3>
      <p className="text-gray-600 whitespace-pre-line">{content}</p>
    </div>
  );
}

export default function About() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const handleQuerySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Query submitted:', formData);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-white py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-16">Meet the Team</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-20">
          <TeamMember
            name="Diya Mittal"
            role="Web Developer"
          />
          <TeamMember
            name="Anwesa Ray"
            role="ML Engineer"
          />
          <TeamMember
            name="Siya Bojewar"
            role="Data Analyst"
          />
          <TeamMember
            name="Naman Shrivastava"
            role="Team Lead"
          />
          <TeamMember
            name="Khushi Gupta"
            role="Deep Learning Expert"
          />
        </div>

        <h2 className="text-3xl font-bold text-center text-gray-900 mb-16">Contact Us</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <ContactCard
            icon={<Mail className="h-8 w-8 text-purple-600" />}
            title="Email"
            content="contact@coupongenie.com"
          />
          <ContactCard
            icon={<Phone className="h-8 w-8 text-purple-600" />}
            title="Phone"
            content="+91 (800) 123-4567"
          />
          <ContactCard
            icon={<Building2 className="h-8 w-8 text-purple-600" />}
            title="Office"
            content="123 Tech Park, Sector 15\nMumbai, Maharashtra 400001"
          />
        </div>

        <div className="max-w-2xl mx-auto">
          <h3 className="text-2xl font-bold text-center text-gray-900 mb-8">Raise a Query</h3>
          <form onSubmit={handleQuerySubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700">Name</label>
              <input
                type="text"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Email</label>
              <input
                type="email"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Message</label>
              <textarea
                rows={4}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                value={formData.message}
                onChange={(e) => setFormData({...formData, message: e.target.value})}
              />
            </div>
            <button
              type="submit"
              className="w-full bg-purple-600 text-white py-2 px-4 rounded-md hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2"
            >
              Submit Query
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}