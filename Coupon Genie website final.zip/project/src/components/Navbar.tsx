import { Gift } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Navbar() {
  return (
    <nav className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center">
            <Gift className="h-8 w-8 text-purple-600" />
            <span className="ml-2 text-xl font-semibold text-gray-900">Coupon Genie</span>
          </Link>
          <div className="flex space-x-8">
            <Link to="/features" className="text-gray-600 hover:text-purple-600">Features</Link>
            <Link to="/predict" className="text-gray-600 hover:text-purple-600">Predict</Link>
            <Link to="/about" className="text-gray-600 hover:text-purple-600">About</Link>
          </div>
        </div>
      </div>
    </nav>
  );
}